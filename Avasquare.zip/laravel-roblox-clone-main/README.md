<p align="center"><img src="https://raw.githubusercontent.com/FoxxoSnoot/laravel-roblox-clone/main/public/img/logo.png" width="400" style="max-width: 100%;"></p>
<hr>
Straight up terrible. But it's old code that will otherwise rot away, so enjoy, skids.
