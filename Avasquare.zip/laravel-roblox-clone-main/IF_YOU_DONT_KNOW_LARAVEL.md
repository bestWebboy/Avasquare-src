# File Structure Layout thing to help you out a bit

If you want to change/add anything in the backend, go to /app/Http/Controllers/Web/ (For the website itself)

If you want to change/add anything in the frontend, go to /resources/views/web/ (For the website itself)

If you want to change/add routing options (make links pretty basically), go to /routes/web.php (For the website itself)
